<article>
	<div class="entry-context context-single">
		<?php the_content(); ?>
	</div>
</article>