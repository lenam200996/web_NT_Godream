<article>
	<!-- <div class="entry-thumbnail">
		<?php //the_post_thumbnail('thumbnail'); ?>
	</div>	
	<div class="entry-title">
		<?php //the_title(); ?>
	</div> -->
	<div class="entry-context context-single">
		<?php the_content(); ?>
	</div>
</article>