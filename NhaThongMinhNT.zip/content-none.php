<div class="no-post">
	<?php _e('Post not found!','mytheme');?>
</div>