<?php 
	require get_template_directory() . '/core/post-types/dichvu.php';
	require get_template_directory() . '/core/post-types/duan.php';
	require get_template_directory() . '/core/post-types/sanpham.php';
	require get_template_directory() . '/core/post-types/phanhoi.php';
 ?>